export const environment = {
  production: true,
  nextApiUrl: 'https://www.last.fm/api',
  nextSpaceUrl: 'https://www.last.fm/de',
  Api_key: 'c0998634535f7b4832a31b40fe75aee9'
};
